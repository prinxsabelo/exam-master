<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ExamTracker extends Model
{
    //
}
